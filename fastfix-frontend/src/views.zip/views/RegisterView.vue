<template>
    <div class="auth-container">
      <h1 class="text-3xl font-bold text-center mb-6">Crear cuenta</h1>
      <form @submit.prevent="register" class="space-y-4">
        <div>
          <label for="name" class="block text-sm font-medium text-gray-700">Nombre completo</label>
          <input
            v-model="name"
            type="text"
            id="name"
            required
            class="input"
            placeholder="Ej. Giovanni Barroso"
          />
        </div>
  
        <div>
          <label for="email" class="block text-sm font-medium text-gray-700">Correo electrónico</label>
          <input
            v-model="email"
            type="email"
            id="email"
            required
            class="input"
            placeholder="ejemplo@correo.com"
          />
        </div>
  
        <div>
          <label for="password" class="block text-sm font-medium text-gray-700">Contraseña</label>
          <input
            v-model="password"
            type="password"
            id="password"
            required
            class="input"
            placeholder="Mínimo 8 caracteres"
          />
        </div>
  
        <div>
          <label for="password_confirmation" class="block text-sm font-medium text-gray-700">Confirmar contraseña</label>
          <input
            v-model="password_confirmation"
            type="password"
            id="password_confirmation"
            required
            class="input"
            placeholder="Repite la contraseña"
          />
        </div>
  
        <div v-if="errorMessage" class="text-red-600 text-sm">
          {{ errorMessage }}
        </div>
  
        <button type="submit" class="btn-primary w-full">Registrarse</button>
      </form>
    </div>
  </template>
  
  <script setup>
  import { ref } from 'vue'
  import axiosInstance from '@/utils/axios'
  import { useRouter } from 'vue-router'
  
  const name = ref('')
  const email = ref('')
  const password = ref('')
  const password_confirmation = ref('')
  const errorMessage = ref('')
  const router = useRouter()
  
  const register = async () => {
    try {
      const response = await axiosInstance.post('/register', {
        name: name.value,
        email: email.value,
        password: password.value,
        password_confirmation: password_confirmation.value,
      })
  
      const token = response.data.token
      localStorage.setItem('token', token)
      router.push('/')
    } catch (error) {
      console.error(error)
      errorMessage.value = error.response?.data?.message || 'Error al registrarse.'
    }
  }
  </script>
  
  <style scoped>
  .auth-container {
    max-width: 400px;
    margin: 4rem auto;
    padding: 2rem;
    background-color: #fff;
    border-radius: 12px;
    box-shadow: 0 0 12px rgba(0, 0, 0, 0.05);
  }
  
  .input {
    width: 100%;
    padding: 0.6rem;
    border: 1px solid #ccc;
    border-radius: 8px;
    outline: none;
    transition: border-color 0.2s;
  }
  
  .input:focus {
    border-color: #6366f1;
  }
  
  .btn-primary {
    background-color: #6366f1;
    color: white;
    padding: 0.6rem;
    font-weight: bold;
    border-radius: 8px;
    border: none;
    cursor: pointer;
    transition: background-color 0.2s;
  }
  
  .btn-primary:hover {
    background-color: #4f46e5;
  }
  </style>
  